export const CONFIG = {

	apiUrl: {
		DEV: "http://seller.dev.sellingathome.com",
		PREPROD: "http://demoseller.sellingathome.com",
		PROD: "http://seller.sellingathome.com",
		TEST: 'https://restcountries.eu/rest/v2/all'
	},


};